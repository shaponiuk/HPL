module Messages.Messages where

printNoFile :: IO ()
printNoFile = putStrLn "TODO"

printTooManyFiles :: IO ()
printTooManyFiles = putStrLn "TODO"
